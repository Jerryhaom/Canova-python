#!/usr/bin/python
from canova_source import *

if __name__ == '__main__':
    '''
    This is a canova python package
    '''
    canova()
